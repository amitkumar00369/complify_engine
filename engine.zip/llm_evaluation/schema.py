"""Structured evaluation result (generic: any product, any standard body).

The AI fills `EvaluationAI` (strict JSON schema). Filled by md_parser from the model's markdown answer.
"""
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

FinalVerdict = Literal[
    "REJECT — INSUFFICIENT TECHNICAL EVIDENCE",
    "REPORT ACCEPTED — PRODUCT COMPLIANCE DEMONSTRATED",
    "REPORT ACCEPTED SUBJECT TO MINOR CORRECTIONS",
    "REPORT CORRECTION / REPLACEMENT REQUIRED — PRODUCT COMPLIANCE NOT DETERMINED — CERTIFICATION HOLD",
    "REPORT REJECTED — NON-CONFORMITY ESTABLISHED",
]
Severity = Literal["Critical", "High", "Medium", "Low", "Not stated"]
GapType = Literal["PRODUCT_IDENTITY_CONFLICT", "NUMERIC_MISMATCH", "LIMIT_EXCEEDED", "INCORRECT_TEST_CONDITION",
                  "MISSING_EVIDENCE", "CLAUSE_NOT_ADDRESSED", "UNJUSTIFIED_NOT_APPLICABLE",
                  "STANDARD_VERSION_MISMATCH", "DOCUMENT_INTEGRITY", "OTHER", "NOT_STATED"]


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Finding(_Strict):
    clause: str = Field(description="Clause number(s), e.g. '7.1' or '10.1; 10.2'; '—' if general")
    gap_type: GapType
    finding: str = Field(description="Finding reason: what the report shows (values, units) and why it does not "
                                     "meet the requirement")
    reason: str = Field(description="Normative requirement: what the supplied standard requires, one sentence")
    required_action: str = Field(description="One imperative sentence")
    pages: str = Field(description="Report PDF pages, e.g. 'PDF pp.14,79'")
    severity: Severity = Field(description="Critical: blocks any compliance decision or a measured failure; "
                                           "High: evidence missing or wrong for an applicable safety clause; "
                                           "Medium: incomplete or inconsistent record; Low: editorial")
    report_quote: str = Field(description="Verbatim words (max 25) copied from the REPORT that show the finding; "
                                          "'none' if the finding is an absence")
    standard_quote: str = Field(description="Verbatim words (max 25) copied from the supplied STANDARD stating the "
                                            "requirement, or 'not in supplied standards'")
    code_verified: bool = Field(description="Always false; set by code for its own deterministic checks")
    report_check: str = Field(description="Always 'not checked'; filled by code")
    standard_check: str = Field(description="Always 'not checked'; filled by code")


class ClauseNote(BaseModel):
    clause: str
    critical: bool
    note: str


class EvaluationAI(_Strict):
    title_product: str = Field(description="Product type and brand, e.g. 'INGCO SUBMERSIBLE PUMP'")
    report_number: str
    laboratory: str
    report_date: str
    product_declared: str = Field(description="Brand, model, ratings, class, IP as declared on cover/nameplate")
    declared_model: str
    standards_claimed: str = Field(description="Standards and editions the report claims, with pages if they differ")
    standards_evaluated: str = Field(description="Supplied standards used, and what could not be verified")
    final_verdict: FinalVerdict
    reason: str = Field(description="One or two sentences behind the verdict")
    recommended_action: str = Field(description="One sentence: what must happen before certification can proceed")
    conclusion: str = Field(description="One paragraph")
    tested_model_matches_declared: bool = Field(description="False if the tested sample/model/rating differs from the declared product")
    findings: list[Finding]