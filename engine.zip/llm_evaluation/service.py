"""Run folder -> OpenAI evaluation -> gap JSON.

Input  (written by the engine pipeline for every run, BLOCKED runs included):
    <run_dir>/standards/effective_kb.json
    <run_dir>/report/report_evidence.json
Output (inside the run folder, so the existing S3 sync uploads it with the rest):
    <run_dir>/ai_evaluation/llm_input.md      exact text sent to the model (standard + report)
    <run_dir>/ai_evaluation/evaluation.md     model answer as returned
    <run_dir>/ai_evaluation/evaluation.json   gap JSON (report_id, gaps, final_summary)
    <run_dir>/ai_evaluation/usage.json        model, tokens, estimated cost, quote-check counts

Settings (.env):
    OPENAI_API_KEY               required for the real call
    OPENAI_MODEL                 default gpt-6.1-terra
    OPENAI_MAX_OUTPUT_TOKENS     default 24000
    AI_EVALUATION_ENABLED        default true (set false to skip the call on POST /reports)
    OPENAI_PRICE_INPUT_PER_M     default 1.0   } USD per 1M tokens, for the cost estimate only
    OPENAI_PRICE_OUTPUT_PER_M    default 5.0   }
    OPENAI_LONG_CONTEXT_TOKENS   default 272000: above this many input tokens the whole request is
    OPENAI_PRICE_INPUT_LONG_PER_M default 2.0     billed at the long-context rates
    OPENAI_PRICE_OUTPUT_LONG_PER_M default 7.5
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

from llm_evaluation.context_builder import BuiltContext, build_context
from llm_evaluation.evidence_check import verify_findings
from llm_evaluation.gap_report import GapReportParser
from llm_evaluation.md_parser import parse_chat_markdown
from llm_evaluation.prompt import SYSTEM_INSTRUCTIONS, build_input

logger = logging.getLogger(__name__)

OUT_DIR = "ai_evaluation"


class AIEvaluationError(RuntimeError):
    pass


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except ValueError:
        return default


def enabled() -> bool:
    return os.environ.get("AI_EVALUATION_ENABLED", "true").strip().lower() not in ("0", "false", "no", "off") \
        and bool(os.environ.get("OPENAI_API_KEY"))


def estimate_cost(input_tokens: int | None, output_tokens: int | None) -> float | None:
    if input_tokens is None:
        return None
    long = input_tokens > int(_env_float("OPENAI_LONG_CONTEXT_TOKENS", 272000))
    pin = _env_float("OPENAI_PRICE_INPUT_LONG_PER_M" if long else "OPENAI_PRICE_INPUT_PER_M", 2.0 if long else 1.0)
    pout = _env_float("OPENAI_PRICE_OUTPUT_LONG_PER_M" if long else "OPENAI_PRICE_OUTPUT_PER_M", 7.5 if long else 5.0)
    return round(input_tokens / 1e6 * pin + (output_tokens or 0) / 1e6 * pout, 4)


def load_context(run_dir: Path) -> BuiltContext:
    kb_path = run_dir / "standards" / "effective_kb.json"
    ev_path = run_dir / "report" / "report_evidence.json"
    missing = [str(p.relative_to(run_dir)) for p in (kb_path, ev_path) if not p.is_file()]
    if missing:
        raise AIEvaluationError(f"Run has no {', '.join(missing)} (pipeline stopped before these steps)")
    return build_context(json.loads(kb_path.read_text(encoding="utf-8")),
                         json.loads(ev_path.read_text(encoding="utf-8")))


def _input_markdown(ctx: BuiltContext) -> str:
    return f"{ctx.standard_text}\n\n---\n\n{ctx.report_text}\n"


def call_openai(ctx: BuiltContext, client=None) -> dict:
    """One Responses API call, no conversation/thread, no file upload. Returns text + usage."""
    if client is None:
        if not os.environ.get("OPENAI_API_KEY"):
            raise AIEvaluationError("OPENAI_API_KEY is not set")
        from openai import OpenAI
        client = OpenAI(timeout=_env_float("OPENAI_TIMEOUT_SECONDS", 900))
    model = os.environ.get("OPENAI_MODEL", "gpt-6.1-terra")
    max_out = int(_env_float("OPENAI_MAX_OUTPUT_TOKENS", 24000))
    t0 = time.time()
    try:
        resp = client.responses.create(model=model, instructions=SYSTEM_INSTRUCTIONS,
                                       input=build_input(ctx.standard_text, ctx.report_text),
                                       max_output_tokens=max_out)
    except Exception as exc:  # noqa: BLE001
        text = str(exc)
        if "insufficient_quota" in text or "credit" in text.lower():
            raise AIEvaluationError("OpenAI credits exhausted") from exc
        raise AIEvaluationError(f"OpenAI request failed: {type(exc).__name__}: {exc}") from exc
    usage = getattr(resp, "usage", None)
    details = getattr(usage, "input_tokens_details", None)
    inc = getattr(resp, "incomplete_details", None)
    truncated = getattr(resp, "status", "") == "incomplete" and getattr(inc, "reason", "") == "max_output_tokens"
    in_tok, out_tok = getattr(usage, "input_tokens", None), getattr(usage, "output_tokens", None)
    return {
        "text": (getattr(resp, "output_text", "") or "").strip(),
        "model": getattr(resp, "model", model),
        "response_id": getattr(resp, "id", None),
        "input_tokens": in_tok,
        "cached_input_tokens": getattr(details, "cached_tokens", None),
        "output_tokens": out_tok,
        "estimated_cost_usd": estimate_cost(in_tok, out_tok),
        "truncated": truncated,
        "seconds": round(time.time() - t0, 1),
    }


def evaluate_run(run_dir: str | Path, *, client=None, force: bool = False) -> dict:
    """Evaluate one engine run. Re-uses a stored result unless force=True."""
    run_dir = Path(run_dir)
    out = run_dir / OUT_DIR
    done = out / "evaluation.json"
    if done.is_file() and not force:
        return {"evaluation": json.loads(done.read_text(encoding="utf-8")),
                "usage": _read(out / "usage.json"), "from_cache": True}

    ctx = load_context(run_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "llm_input.md").write_text(_input_markdown(ctx), encoding="utf-8")
    logger.info("AI evaluation %s: ~%s input tokens (standard %s chars, report %s chars)",
                run_dir.name, ctx.est_tokens, len(ctx.standard_text), len(ctx.report_text))

    result = call_openai(ctx, client)
    (out / "evaluation.md").write_text(result["text"], encoding="utf-8")
    if result["truncated"]:
        raise AIEvaluationError("Model answer was cut off at OPENAI_MAX_OUTPUT_TOKENS; raise it and retry "
                                f"(partial answer kept in {OUT_DIR}/evaluation.md)")

    ai = parse_chat_markdown(result["text"])
    if not ai.findings and "## Findings" not in result["text"]:
        raise AIEvaluationError(f"Model answer is not in the expected format (see {OUT_DIR}/evaluation.md)")
    ai = verify_findings(ai, ctx)
    gap_json = GapReportParser.from_evaluation(ai)
    (out / "evaluation.json").write_text(json.dumps(gap_json, indent=2, ensure_ascii=False), encoding="utf-8")

    checks = [g["verification_status"] for g in gap_json["gaps"]]
    usage = {k: v for k, v in result.items() if k != "text"}
    usage.update({
        "created_at": datetime.now(timezone.utc).isoformat(),
        "context_chars": ctx.chars,
        "context_tokens_estimate": ctx.est_tokens,
        "standards": ctx.standard_labels,
        "verification": {s: checks.count(s) for s in sorted(set(checks))},
    })
    (out / "usage.json").write_text(json.dumps(usage, indent=2), encoding="utf-8")
    return {"evaluation": gap_json, "usage": usage, "from_cache": False}


def dry_run(run_dir: str | Path) -> dict:
    """Build and save the model input without calling OpenAI: shows size and expected cost."""
    run_dir = Path(run_dir)
    ctx = load_context(run_dir)
    out = run_dir / OUT_DIR
    out.mkdir(parents=True, exist_ok=True)
    path = out / "llm_input.md"
    path.write_text(_input_markdown(ctx), encoding="utf-8")
    est = ctx.est_tokens + len(SYSTEM_INSTRUCTIONS) // 4
    return {"llm_input": str(path), "standards": ctx.standard_labels, "standard_chars": len(ctx.standard_text),
            "report_chars": len(ctx.report_text), "input_tokens_estimate": est,
            "estimated_cost_usd": estimate_cost(est, 8000)}


def _read(p: Path):
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None